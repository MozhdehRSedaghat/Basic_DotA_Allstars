/**
 * Created by VAIO on 12/9/2015.
 */
package GameEngine;
public class DotaExceptionBase extends Exception{

    /**
     *
     */
    private static final long serialVersionUID = -3800920627229184953L;

}